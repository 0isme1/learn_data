#pragma once

#include <iostream>
#include <ranges>
#include <chrono>
#include <format>
#include <future>
#include <numbers>
#include <string>


using namespace std;
using namespace std::chrono;



void test01();
void test02();
void test03();
void test04();
void test05();
void test06();
void test07();
void test08();
void test09();


