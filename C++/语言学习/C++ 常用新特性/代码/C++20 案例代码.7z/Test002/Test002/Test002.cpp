﻿
#include <iostream>
#include "mycode.h"

using namespace std;

int main() {

	//test01();
	//test02();
	//test03();
	//test04();
	//test05();
	//test06();
	//test07();
	//test08();
	test09();
	




	return 0;
}

