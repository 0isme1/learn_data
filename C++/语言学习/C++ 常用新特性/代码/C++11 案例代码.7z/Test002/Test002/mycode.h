#pragma once
#include <iostream>

#include <vector>
#include <map>
#include <typeinfo>
#include <algorithm>
#include <functional>
#include <memory>
#include <array>
#include <forward_list>
#include <unordered_set>
#include <unordered_map>

using namespace std;

template <class T>
class Student;

void test01();
void test02();
void test03();
void test04();
void test05();
void test06();
void test07();
void test08();
void test09();
void test10();
void test11();
void test12();
void test13();
void test14();
void test15();
void test16();
void test17();
void test18();
void test19();
void test20();
void test21();
void test22();
void test23();
void test24();
void test25();
void test26();
void test27();
void test28();






auto func1(int v1, int v2);


