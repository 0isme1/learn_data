﻿// x86Study.cpp : 此文件包含 "main" 函数。程序执行将在此处开始并结束。
//

#include <iostream>

struct registers {
	unsigned eax;
	unsigned ecx;
	unsigned edx;
	unsigned ebx;
	unsigned esp;
	unsigned ebp;
	unsigned esi;
	unsigned edi;
};

#ifndef _WIN64
void show_registers()
{
	registers regs;
	_asm {
		;// PUSHA;
		PUSHAD;
		POP regs.edi;
		POP regs.esi;
		POP regs.ebp;
		POP regs.esp;
		POP regs.ebx;
		POP regs.edx;
		POP regs.ecx;
		POP regs.eax;
	}
	printf("eax = %08X ebx = %08x ecx=%08x edx = %08x\n", regs.eax, regs.ebx, regs.ecx, regs.edx);
	printf("esp = %08X ebp = %08x esi=%08x edi = %08x\n", regs.esp, regs.ebp, regs.esi, regs.edi);
}

void change_registers()
{
	registers regs;

	_asm {
		;// PUSHA;
		PUSHAD;
		POP regs.edi;
		POP regs.esi;
		POP regs.ebp;
		POP regs.esp;
		POP regs.ebx;
		POP regs.edx;
		POP regs.ecx;
		POP regs.eax;
	}
	regs.eax = 1;
	regs.ebx = 2;
	regs.ecx = 3;
	regs.edx = 4;
	//regs.esp = 5;
	//regs.ebp = 6;
	regs.esi = 7;
	regs.edi = 8;
	_asm {
		PUSH regs.eax;
		PUSH regs.ecx;
		PUSH regs.edx;
		PUSH regs.ebx;
		PUSH regs.esp;
		PUSH regs.ebp;
		PUSH regs.esi;
		PUSH regs.edi;
		POPAD;
	}
	printf("eax = %08X ebx = %08x ecx=%08x edx = %08x\n", regs.eax, regs.ebx, regs.ecx, regs.edx);
	printf("esp = %08X ebp = %08x esi=%08x edi = %08x\n", regs.esp, regs.ebp, regs.esi, regs.edi);
}
#endif
#ifdef _WIN64
extern "C" void study();
#endif
int main(int argc, char** argv)
{
	unsigned short* pFlags = NULL;//RF NT IOPL ODIT SZ-A -P-C
	unsigned nEax = 0xCD7;// 0  0   00  1000 1101 0101  8D5
	unsigned nEbx = 0x10000;
	unsigned* pEax = &nEax;
	uint64_t result = (uint64_t)nEbx * nEbx;
	unsigned char scTemp = -128;
	float fdata = 99.999f, fdata2 = 0.0f;
	double ddata = 99.999, ddata2 = 0.0;
	char s0data[8] = "aacdefg";
	char s1data[8] = "";
	unsigned short nWord = 0;
#ifndef _WIN64
	//32位系统下面
	_asm {
		MOV AL, 055H;
		RCR AL, 1;
		RCR AL, 8;
		RCR AL, 2;
		RCR AL, 4;
		MOV AL, 03FH;
		ROR AL, 8;
		ROR AL, 1;
		ROR AL, 2;
		ROR AL, 4;
		ROR AL, 1;
	}

#else
	study();
#endif

	int32_t data = 0x10000000;
	data = data / 3;
	printf("nEax=%08X nEbx=%08X pEax=%08p pFlags=%08p\r\n", nEax, nEbx, pEax, pFlags);
}
