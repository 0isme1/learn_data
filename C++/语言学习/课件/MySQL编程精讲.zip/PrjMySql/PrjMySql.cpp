// PrjMySql.cpp : 此文件包含 "main" 函数。程序执行将在此处开始并结束。
//

#include <iostream>
#include <mysql.h>

void show_result(MYSQL_RES* result)
{
	unsigned nFields = mysql_num_fields(result);
	my_ulonglong nRows = mysql_num_rows(result);
	MYSQL_FIELD* fields = mysql_fetch_fields(result);
	MYSQL_ROW row;
	do {
		row = mysql_fetch_row(result);
		if (row != NULL) {
			for (unsigned j = 0; j < nFields; j++) {
				std::cout << "type:" << fields[j].type << " " << fields[j].name << ":" << row[j] << std::endl;
			}
		}
	} while (row != NULL);
}

int lession04()
{
	MYSQL* mysql = new MYSQL();
	//MYSQL mysql;//占用的是栈上的内存
	MYSQL* pDB = mysql_init(mysql);
	if (pDB == NULL) {
		std::cout << "mysql_init failed!" << std::endl;
		return -1;
	}
	pDB = mysql_real_connect(pDB, "localhost", "root", "FengPan12#$56", "mysql", 3306, NULL, 0);
	std::cout << pDB << std::endl;
	if (pDB) {
		std::string sql = "";
		int ret = mysql_real_query(pDB, sql.c_str(), (unsigned long)sql.size());
		if (ret != 0) {
			std::cout << "mysql error:" << mysql_error(pDB) << std::endl;
		}
		mysql_close(pDB);
	}

	delete mysql;
	return 0;
}

int lession07()
{
	MYSQL* mysql = new MYSQL();
	//MYSQL mysql;//占用的是栈上的内存
	MYSQL* pDB = mysql_init(mysql);
	if (pDB == NULL) {
		std::cout << "mysql_init failed!" << std::endl;
		return -1;
	}
	pDB = mysql_real_connect(pDB, "localhost", "root", "FengPan12#$56", "mysql", 3306, NULL, 0);
	std::cout << pDB << std::endl;
	if (pDB) {
		std::string sql = "CREATE USER 'hello'@'localhost' IDENTIFIED BY '123456'";
		int ret = mysql_real_query(pDB, sql.c_str(), (unsigned long)sql.size());
		if (ret != 0) {
			std::cout << "mysql error:" << mysql_error(pDB) << std::endl;
		}
		MYSQL_RES* result = mysql_use_result(mysql);
		if (result != NULL) {
			unsigned nFields = mysql_num_fields(result);
			my_ulonglong nRows = mysql_num_rows(result);
			MYSQL_FIELD* fields = mysql_fetch_fields(result);
			for (unsigned i = 0; i < nRows; i++) {
				MYSQL_ROW row = mysql_fetch_row(result);
				if (row != NULL) {
					for (unsigned j = 0; j < nFields; j++) {
						std::cout << "type:" << fields[j].type << " " << fields[j].name << ":" << row[j] << std::endl;
					}
				}
				std::cout << "===================================================" << std::endl;
			}
			mysql_free_result(result);
		}

		sql = "GRANT ALL ON *.* TO 'hello'@'localhost'";
		ret = mysql_real_query(pDB, sql.c_str(), (unsigned long)sql.size());
		if (ret != 0) {
			std::cout << "mysql error:" << mysql_error(pDB) << std::endl;
			return -1;
		}
		result = mysql_use_result(mysql);
		if (result != NULL) {
			unsigned nFields = mysql_num_fields(result);
			my_ulonglong nRows = mysql_num_rows(result);
			MYSQL_FIELD* fields = mysql_fetch_fields(result);
			for (unsigned i = 0; i < nRows; i++) {
				MYSQL_ROW row = mysql_fetch_row(result);
				if (row != NULL) {
					for (unsigned j = 0; j < nFields; j++) {
						std::cout << "type:" << fields[j].type << " " << fields[j].name << ":" << row[j] << std::endl;
					}
				}
				std::cout << "===================================================" << std::endl;
			}
			mysql_free_result(result);
		}
		mysql_close(pDB);
	}

	delete mysql;
	return 0;
}

int lession08()
{
	MYSQL* mysql = new MYSQL();
	//MYSQL mysql;//占用的是栈上的内存
	MYSQL* pDB = mysql_init(mysql);
	if (pDB == NULL) {
		std::cout << "mysql_init failed!" << std::endl;
		return -1;
	}
	pDB = mysql_real_connect(pDB, "localhost", "root", "FengPan12#$56", "mysql", 3306, NULL, 0);
	std::cout << pDB << std::endl;
	if (pDB) {
		std::string sql = "CREATE DATABASE hello";
		int ret = mysql_real_query(pDB, sql.c_str(), (unsigned long)sql.size());
		if (ret != 0) {
			std::cout << "mysql error:" << mysql_error(pDB) << std::endl;
		}
		MYSQL_RES* result = mysql_use_result(mysql);
		if (result != NULL) {
			show_result(result);
			std::cout << "===================================================" << std::endl;
			mysql_free_result(result);
		}
		//授予权限
		sql = "GRANT ALL ON hello.* TO 'hello'@'localhost';";
		ret = mysql_real_query(pDB, sql.c_str(), (unsigned long)sql.size());
		if (ret != 0) {
			std::cout << "mysql error:" << mysql_error(pDB) << std::endl;
			return -1;
		}
		result = mysql_use_result(mysql);
		if (result != NULL) {
			show_result(result);
			std::cout << "===================================================" << std::endl;
			mysql_free_result(result);
		}


		sql = "USE hello;";
		ret = mysql_real_query(pDB, sql.c_str(), (unsigned long)sql.size());
		if (ret != 0) {
			std::cout << "mysql error:" << mysql_error(pDB) << std::endl;
			return -1;
		}
		result = mysql_use_result(mysql);
		if (result != NULL) {
			show_result(result);
			std::cout << "===================================================" << std::endl;
			mysql_free_result(result);
		}

		sql = "DROP DATABASE hello;";
		ret = mysql_real_query(pDB, sql.c_str(), (unsigned long)sql.size());
		if (ret != 0) {
			std::cout << "mysql error:" << mysql_error(pDB) << std::endl;
			return -1;
		}
		result = mysql_use_result(mysql);
		if (result != NULL) {
			show_result(result);
			std::cout << "===================================================" << std::endl;
			mysql_free_result(result);
		}
		mysql_close(pDB);
	}

	delete mysql;
	return 0;
}

int lession09() {
	MYSQL* mysql = new MYSQL();
	//MYSQL mysql;//占用的是栈上的内存
	MYSQL* pDB = mysql_init(mysql);
	if (pDB == NULL) {
		std::cout << "mysql_init failed!" << std::endl;
		return -1;
	}
	pDB = mysql_real_connect(pDB, "localhost", "root", "FengPan12#$56", "mysql", 3306, NULL, 0);
	std::cout << pDB << std::endl;
	if (pDB) {
		std::string sql = "CREATE DATABASE hello";
		int ret = mysql_real_query(pDB, sql.c_str(), (unsigned long)sql.size());
		if (ret != 0) {
			std::cout << "mysql error:" << mysql_error(pDB) << std::endl;
		}
		MYSQL_RES* result = mysql_use_result(mysql);
		if (result != NULL) {
			show_result(result);
			std::cout << "===================================================" << std::endl;
			mysql_free_result(result);
		}
		//授予权限
		sql = "GRANT ALL ON hello.* TO 'hello'@'localhost';";
		ret = mysql_real_query(pDB, sql.c_str(), (unsigned long)sql.size());
		if (ret != 0) {
			std::cout << "mysql error:" << mysql_error(pDB) << std::endl;
			return -1;
		}
		result = mysql_use_result(mysql);
		if (result != NULL) {
			show_result(result);
			std::cout << "===================================================" << std::endl;
			mysql_free_result(result);
		}


		sql = "USE hello;";
		ret = mysql_real_query(pDB, sql.c_str(), (unsigned long)sql.size());
		if (ret != 0) {
			std::cout << "mysql error:" << mysql_error(pDB) << std::endl;
			return -1;
		}
		result = mysql_use_result(mysql);
		if (result != NULL) {
			show_result(result);
			std::cout << "===================================================" << std::endl;
			mysql_free_result(result);
		}

		sql = "CREATE TABLE IF NOT EXISTS `hello` (`编号` NVARCHAR(16) PRIMARY KEY)ENGINE=InnoDB DEFAULT CHARSET=utf8;";
		ret = mysql_real_query(pDB, sql.c_str(), (unsigned long)sql.size());
		if (ret != 0) {
			std::cout << "mysql error:" << mysql_error(pDB) << std::endl;
			return -1;
		}
		sql = "DROP TABLE `hello`;";
		ret = mysql_real_query(pDB, sql.c_str(), (unsigned long)sql.size());
		if (ret != 0) {
			std::cout << "mysql error:" << mysql_error(pDB) << std::endl;
			return -1;
		}
		sql = "DROP DATABASE hello;";
		ret = mysql_real_query(pDB, sql.c_str(), (unsigned long)sql.size());
		if (ret != 0) {
			std::cout << "mysql error:" << mysql_error(pDB) << std::endl;
			return -1;
		}
		mysql_close(pDB);
	}

	delete mysql;
	return 0;
}

int lession10()
{
	MYSQL* mysql = new MYSQL();
	//MYSQL mysql;//占用的是栈上的内存
	MYSQL* pDB = mysql_init(mysql);
	if (pDB == NULL) {
		std::cout << "mysql_init failed!" << std::endl;
		return -1;
	}
	pDB = mysql_real_connect(pDB, "localhost", "root", "FengPan12#$56", "mysql", 3306, NULL, 0);
	std::cout << pDB << std::endl;
	if (pDB) {
		std::string sql = "CREATE DATABASE hello";
		int ret = mysql_real_query(pDB, sql.c_str(), (unsigned long)sql.size());
		if (ret != 0) {
			std::cout << "mysql error:" << mysql_error(pDB) << std::endl;
		}
		MYSQL_RES* result = mysql_use_result(mysql);
		if (result != NULL) {
			show_result(result);
			std::cout << "===================================================" << std::endl;
			mysql_free_result(result);
		}
		//授予权限
		sql = "GRANT ALL ON hello.* TO 'hello'@'localhost';";
		ret = mysql_real_query(pDB, sql.c_str(), (unsigned long)sql.size());
		if (ret != 0) {
			std::cout << "mysql error:" << mysql_error(pDB) << std::endl;
			return -1;
		}
		result = mysql_use_result(mysql);
		if (result != NULL) {
			show_result(result);
			std::cout << "===================================================" << std::endl;
			mysql_free_result(result);
		}


		sql = "USE hello;";
		ret = mysql_real_query(pDB, sql.c_str(), (unsigned long)sql.size());
		if (ret != 0) {
			std::cout << "mysql error:" << mysql_error(pDB) << std::endl;
			return -1;
		}
		result = mysql_use_result(mysql);
		if (result != NULL) {
			show_result(result);
			std::cout << "===================================================" << std::endl;
			mysql_free_result(result);
		}

		sql = "CREATE TABLE IF NOT EXISTS `hello` (`编号` NVARCHAR(16) PRIMARY KEY)ENGINE=InnoDB DEFAULT CHARSET=utf8;";
		ret = mysql_real_query(pDB, sql.c_str(), (unsigned long)sql.size());
		if (ret != 0) {
			std::cout << "mysql error:" << mysql_error(pDB) << std::endl;
			return -1;
		}
		sql = "INSERT INTO `hello` (`编号`) VALUES (\"9527\");";
		ret = mysql_real_query(pDB, sql.c_str(), (unsigned long)sql.size());
		if (ret != 0) {
			std::cout << "mysql error:" << mysql_error(pDB) << std::endl;
			return -1;
		}
		sql = "DROP TABLE `hello`;";
		ret = mysql_real_query(pDB, sql.c_str(), (unsigned long)sql.size());
		if (ret != 0) {
			std::cout << "mysql error:" << mysql_error(pDB) << std::endl;
			return -1;
		}
		sql = "DROP DATABASE hello;";
		ret = mysql_real_query(pDB, sql.c_str(), (unsigned long)sql.size());
		if (ret != 0) {
			std::cout << "mysql error:" << mysql_error(pDB) << std::endl;
			return -1;
		}
		mysql_close(pDB);
	}

	delete mysql;
	return 0;
}

int lession11()
{
	MYSQL* mysql = new MYSQL();
	//MYSQL mysql;//占用的是栈上的内存
	MYSQL* pDB = mysql_init(mysql);
	if (pDB == NULL) {
		std::cout << "mysql_init failed!" << std::endl;
		return -1;
	}
	pDB = mysql_real_connect(pDB, "localhost", "root", "FengPan12#$56", "mysql", 3306, NULL, 0);
	std::cout << pDB << std::endl;
	if (pDB) {
		std::string sql = "CREATE DATABASE hello";
		int ret = mysql_real_query(pDB, sql.c_str(), (unsigned long)sql.size());
		if (ret != 0) {
			std::cout << "mysql error:" << mysql_error(pDB) << std::endl;
		}
		MYSQL_RES* result = mysql_use_result(mysql);
		if (result != NULL) {
			show_result(result);
			std::cout << "===================================================" << std::endl;
			mysql_free_result(result);
		}
		//授予权限
		sql = "GRANT ALL ON hello.* TO 'hello'@'localhost';";
		ret = mysql_real_query(pDB, sql.c_str(), (unsigned long)sql.size());
		if (ret != 0) {
			std::cout << "mysql error:" << mysql_error(pDB) << std::endl;
			return -1;
		}
		result = mysql_use_result(mysql);
		if (result != NULL) {
			show_result(result);
			std::cout << "===================================================" << std::endl;
			mysql_free_result(result);
		}


		sql = "USE hello;";
		ret = mysql_real_query(pDB, sql.c_str(), (unsigned long)sql.size());
		if (ret != 0) {
			std::cout << "mysql error:" << mysql_error(pDB) << std::endl;
			return -1;
		}
		result = mysql_use_result(mysql);
		if (result != NULL) {
			show_result(result);
			std::cout << "===================================================" << std::endl;
			mysql_free_result(result);
		}

		sql = "CREATE TABLE IF NOT EXISTS `hello` (`编号` NVARCHAR(16) PRIMARY KEY)ENGINE=InnoDB DEFAULT CHARSET=utf8;";
		ret = mysql_real_query(pDB, sql.c_str(), (unsigned long)sql.size());
		if (ret != 0) {
			std::cout << "mysql error:" << mysql_error(pDB) << std::endl;
			return -1;
		}
		sql = "INSERT INTO `hello` (`编号`) VALUES (\"9527\");";
		ret = mysql_real_query(pDB, sql.c_str(), (unsigned long)sql.size());
		if (ret != 0) {
			std::cout << "mysql error:" << mysql_error(pDB) << std::endl;
			return -1;
		}
		sql = "INSERT INTO `hello` (`编号`) VALUES (\"9528\");";
		ret = mysql_real_query(pDB, sql.c_str(), (unsigned long)sql.size());
		if (ret != 0) {
			std::cout << "mysql error:" << mysql_error(pDB) << std::endl;
			return -1;
		}
		sql = "DELETE FROM `hello` WHERE `编号`=\"9527\";";
		ret = mysql_real_query(pDB, sql.c_str(), (unsigned long)sql.size());
		if (ret != 0) {
			std::cout << "mysql error:" << mysql_error(pDB) << std::endl;
			return -1;
		}
		sql = "DROP TABLE `hello`;";
		ret = mysql_real_query(pDB, sql.c_str(), (unsigned long)sql.size());
		if (ret != 0) {
			std::cout << "mysql error:" << mysql_error(pDB) << std::endl;
			return -1;
		}
		sql = "DROP DATABASE hello;";
		ret = mysql_real_query(pDB, sql.c_str(), (unsigned long)sql.size());
		if (ret != 0) {
			std::cout << "mysql error:" << mysql_error(pDB) << std::endl;
			return -1;
		}
		mysql_close(pDB);
	}

	delete mysql;
	return 0;
}

int lession12()
{
	MYSQL* mysql = new MYSQL();
	//MYSQL mysql;//占用的是栈上的内存
	MYSQL* pDB = mysql_init(mysql);
	if (pDB == NULL) {
		std::cout << "mysql_init failed!" << std::endl;
		return -1;
	}
	pDB = mysql_real_connect(pDB, "localhost", "root", "FengPan12#$56", "mysql", 3306, NULL, 0);
	std::cout << pDB << std::endl;
	if (pDB) {
		std::string sql = "CREATE DATABASE hello";
		int ret = mysql_real_query(pDB, sql.c_str(), (unsigned long)sql.size());
		if (ret != 0) {
			std::cout << "mysql error:" << mysql_error(pDB) << std::endl;
		}
		MYSQL_RES* result = mysql_use_result(mysql);
		if (result != NULL) {
			show_result(result);
			std::cout << "===================================================" << std::endl;
			mysql_free_result(result);
		}
		//授予权限
		sql = "GRANT ALL ON hello.* TO 'hello'@'localhost';";
		ret = mysql_real_query(pDB, sql.c_str(), (unsigned long)sql.size());
		if (ret != 0) {
			std::cout << "mysql error:" << mysql_error(pDB) << std::endl;
			return -1;
		}
		result = mysql_use_result(mysql);
		if (result != NULL) {
			show_result(result);
			std::cout << "===================================================" << std::endl;
			mysql_free_result(result);
		}


		sql = "USE hello;";
		ret = mysql_real_query(pDB, sql.c_str(), (unsigned long)sql.size());
		if (ret != 0) {
			std::cout << "mysql error:" << mysql_error(pDB) << std::endl;
			return -1;
		}
		result = mysql_use_result(mysql);
		if (result != NULL) {
			show_result(result);
			std::cout << "===================================================" << std::endl;
			mysql_free_result(result);
		}

		sql = "CREATE TABLE IF NOT EXISTS `hello` (`编号` NVARCHAR(16) PRIMARY KEY,";
		sql += "`age` INT NOT NULL DEFAULT 18";
		sql += ")ENGINE=InnoDB DEFAULT CHARSET=utf8;";
		ret = mysql_real_query(pDB, sql.c_str(), (unsigned long)sql.size());
		if (ret != 0) {
			std::cout << "mysql error:" << mysql_error(pDB) << std::endl;
			return -1;
		}
		sql = "INSERT INTO `hello` (`编号`,`age`) VALUES (\"9527\",35);";
		ret = mysql_real_query(pDB, sql.c_str(), (unsigned long)sql.size());
		if (ret != 0) {
			std::cout << "mysql error:" << mysql_error(pDB) << std::endl;
			return -1;
		}
		sql = "INSERT INTO `hello` (`编号`,`age`) VALUES (\"9528\",99);";
		ret = mysql_real_query(pDB, sql.c_str(), (unsigned long)sql.size());
		if (ret != 0) {
			std::cout << "mysql error:" << mysql_error(pDB) << std::endl;
			return -1;
		}
		sql = "UPDATE `hello` SET age=18 WHERE `编号`=\"9528\";";
		ret = mysql_real_query(pDB, sql.c_str(), (unsigned long)sql.size());
		if (ret != 0) {
			std::cout << "mysql error:" << mysql_error(pDB) << std::endl;
			return -1;
		}
		sql = "UPDATE `hello` SET age=19 WHERE `age`>=35 AND `age`!=18;";
		ret = mysql_real_query(pDB, sql.c_str(), (unsigned long)sql.size());
		if (ret != 0) {
			std::cout << "mysql error:" << mysql_error(pDB) << std::endl;
			return -1;
		}
		sql = "DELETE FROM `hello` WHERE `编号`=\"9527\";";
		ret = mysql_real_query(pDB, sql.c_str(), (unsigned long)sql.size());
		if (ret != 0) {
			std::cout << "mysql error:" << mysql_error(pDB) << std::endl;
			return -1;
		}
		sql = "DROP TABLE `hello`;";
		ret = mysql_real_query(pDB, sql.c_str(), (unsigned long)sql.size());
		if (ret != 0) {
			std::cout << "mysql error:" << mysql_error(pDB) << std::endl;
			return -1;
		}
		sql = "DROP DATABASE hello;";
		ret = mysql_real_query(pDB, sql.c_str(), (unsigned long)sql.size());
		if (ret != 0) {
			std::cout << "mysql error:" << mysql_error(pDB) << std::endl;
			return -1;
		}
		mysql_close(pDB);
	}

	delete mysql;
	return 0;
}

int make_query(MYSQL* pDB)
{
	std::string sql = "SELECT * FROM `hello`";
	int ret = mysql_real_query(pDB, sql.c_str(), (unsigned long)sql.size());
	if (ret != 0) {
		std::cout << "mysql error:" << mysql_error(pDB) << std::endl;
		return -1;
	}
	MYSQL_RES* result = mysql_use_result(pDB);
	if (result != NULL) {
		show_result(result);
		std::cout << "===================================================" << std::endl;
		mysql_free_result(result);
	}
	return 0;
}

int lession13()
{
	MYSQL* mysql = new MYSQL();
	//MYSQL mysql;//占用的是栈上的内存
	MYSQL* pDB = mysql_init(mysql);
	if (pDB == NULL) {
		std::cout << "mysql_init failed!" << std::endl;
		return -1;
	}
	pDB = mysql_real_connect(pDB, "localhost", "root", "FengPan12#$56", "mysql", 3306, NULL, 0);
	std::cout << pDB << std::endl;
	if (pDB) {
		std::string sql = "CREATE DATABASE hello";
		int ret = mysql_real_query(pDB, sql.c_str(), (unsigned long)sql.size());
		if (ret != 0) {
			std::cout << "mysql error:" << mysql_error(pDB) << std::endl;
		}
		MYSQL_RES* result = mysql_use_result(mysql);
		if (result != NULL) {
			show_result(result);
			std::cout << "===================================================" << std::endl;
			mysql_free_result(result);
		}
		//授予权限
		sql = "GRANT ALL ON hello.* TO 'hello'@'localhost';";
		ret = mysql_real_query(pDB, sql.c_str(), (unsigned long)sql.size());
		if (ret != 0) {
			std::cout << "mysql error:" << mysql_error(pDB) << std::endl;
			return -1;
		}
		result = mysql_use_result(mysql);
		if (result != NULL) {
			show_result(result);
			std::cout << "===================================================" << std::endl;
			mysql_free_result(result);
		}


		sql = "USE hello;";
		ret = mysql_real_query(pDB, sql.c_str(), (unsigned long)sql.size());
		if (ret != 0) {
			std::cout << "mysql error:" << mysql_error(pDB) << std::endl;
			return -1;
		}
		result = mysql_use_result(mysql);
		if (result != NULL) {
			show_result(result);
			std::cout << "===================================================" << std::endl;
			mysql_free_result(result);
		}
		mysql_real_query(pDB, sql.c_str(), (unsigned long)sql.size());
		sql = "CREATE TABLE IF NOT EXISTS `hello` (`编号` NVARCHAR(16) PRIMARY KEY,";
		sql += "`age` INT NOT NULL DEFAULT 18";
		sql += ")ENGINE=InnoDB DEFAULT CHARSET=utf8;";
		ret = mysql_real_query(pDB, sql.c_str(), (unsigned long)sql.size());
		if (ret != 0) {
			std::cout << "mysql error:" << mysql_error(pDB) << std::endl;
			return -1;
		}
		make_query(pDB);
		sql = "INSERT INTO `hello` (`编号`,`age`) VALUES (\"9527\",35);";
		ret = mysql_real_query(pDB, sql.c_str(), (unsigned long)sql.size());
		if (ret != 0) {
			std::cout << "mysql error:" << mysql_error(pDB) << std::endl;
			return -1;
		}
		make_query(pDB);
		sql = "INSERT INTO `hello` (`编号`,`age`) VALUES (\"9528\",99);";
		ret = mysql_real_query(pDB, sql.c_str(), (unsigned long)sql.size());
		if (ret != 0) {
			std::cout << "mysql error:" << mysql_error(pDB) << std::endl;
			return -1;
		}
		make_query(pDB);
		sql = "UPDATE `hello` SET age=18 WHERE `编号`=\"9528\";";
		ret = mysql_real_query(pDB, sql.c_str(), (unsigned long)sql.size());
		if (ret != 0) {
			std::cout << "mysql error:" << mysql_error(pDB) << std::endl;
			return -1;
		}
		make_query(pDB);
		sql = "UPDATE `hello` SET age=19 WHERE `age`>=35 AND `age`!=18;";
		ret = mysql_real_query(pDB, sql.c_str(), (unsigned long)sql.size());
		if (ret != 0) {
			std::cout << "mysql error:" << mysql_error(pDB) << std::endl;
			return -1;
		}
		make_query(pDB);
		sql = "DELETE FROM `hello` WHERE `编号`=\"9527\";";
		ret = mysql_real_query(pDB, sql.c_str(), (unsigned long)sql.size());
		if (ret != 0) {
			std::cout << "mysql error:" << mysql_error(pDB) << std::endl;
			return -1;
		}
		make_query(pDB);
		sql = "DROP TABLE `hello`;";
		ret = mysql_real_query(pDB, sql.c_str(), (unsigned long)sql.size());
		if (ret != 0) {
			std::cout << "mysql error:" << mysql_error(pDB) << std::endl;
			return -1;
		}
		sql = "DROP DATABASE hello;";
		ret = mysql_real_query(pDB, sql.c_str(), (unsigned long)sql.size());
		if (ret != 0) {
			std::cout << "mysql error:" << mysql_error(pDB) << std::endl;
			return -1;
		}
		mysql_close(pDB);
	}

	delete mysql;
	return 0;
}

int lession14()
{
	MYSQL* mysql = new MYSQL();
	//MYSQL mysql;//占用的是栈上的内存
	MYSQL* pDB = mysql_init(mysql);
	if (pDB == NULL) {
		std::cout << "mysql_init failed!" << std::endl;
		return -1;
	}
	pDB = mysql_real_connect(pDB, "localhost", "root", "FengPan12#$56", "mysql", 3306, NULL, 0);
	std::cout << pDB << std::endl;
	if (pDB) {
		std::string sql = "CREATE DATABASE hello";
		int ret = mysql_real_query(pDB, sql.c_str(), (unsigned long)sql.size());
		if (ret != 0) {
			std::cout << "mysql error:" << mysql_error(pDB) << std::endl;
		}
		MYSQL_RES* result = mysql_use_result(mysql);
		if (result != NULL) {
			show_result(result);
			std::cout << "===================================================" << std::endl;
			mysql_free_result(result);
		}
		//授予权限
		sql = "GRANT ALL ON hello.* TO 'hello'@'localhost';";
		ret = mysql_real_query(pDB, sql.c_str(), (unsigned long)sql.size());
		if (ret != 0) {
			std::cout << "mysql error:" << mysql_error(pDB) << std::endl;
			return -1;
		}
		result = mysql_use_result(mysql);
		if (result != NULL) {
			show_result(result);
			std::cout << "===================================================" << std::endl;
			mysql_free_result(result);
		}


		sql = "USE hello;";
		ret = mysql_real_query(pDB, sql.c_str(), (unsigned long)sql.size());
		if (ret != 0) {
			std::cout << "mysql error:" << mysql_error(pDB) << std::endl;
			return -1;
		}

		sql = "CREATE TABLE IF NOT EXISTS `hello` (`编号` NVARCHAR(16) PRIMARY KEY,";
		sql += "`age` INT NOT NULL DEFAULT 18";
		sql += ")ENGINE=InnoDB DEFAULT CHARSET=utf8;";
		ret = mysql_real_query(pDB, sql.c_str(), (unsigned long)sql.size());
		if (ret != 0) {
			std::cout << "mysql error:" << mysql_error(pDB) << std::endl;
			return -1;
		}
		sql = "CREATE TABLE IF NOT EXISTS `teacher` (`编号` NVARCHAR(16) PRIMARY KEY,";
		sql += "`age` INT NOT NULL DEFAULT 18";
		sql += ")ENGINE=InnoDB DEFAULT CHARSET=utf8;";
		ret = mysql_real_query(pDB, sql.c_str(), (unsigned long)sql.size());
		if (ret != 0) {
			std::cout << "mysql error:" << mysql_error(pDB) << std::endl;
			return -1;
		}
		sql = "SET NAMES 'utf8';";
		ret = mysql_real_query(pDB, sql.c_str(), (unsigned long)sql.size());
		if (ret != 0) {
			std::cout << "mysql error:" << mysql_error(pDB) << std::endl;
			return -1;
		}
		sql = "SET CHARACTER SET utf8;";
		ret = mysql_real_query(pDB, sql.c_str(), (unsigned long)sql.size());
		if (ret != 0) {
			std::cout << "mysql error:" << mysql_error(pDB) << std::endl;
			return -1;
		}
		/*sql = "SET CHARACTER_SET_RESULT = utf8";
		ret = mysql_real_query(pDB, sql.c_str(), (unsigned long)sql.size());
		if (ret != 0) {
			std::cout << "mysql error:" << mysql_error(pDB) << std::endl;
			return -1;
		}*/
		make_query(pDB);
		sql = "INSERT INTO `hello` (`编号`,`age`) VALUES (\"9527\",35);";
		ret = mysql_real_query(pDB, sql.c_str(), (unsigned long)sql.size());
		if (ret != 0) {
			std::cout << "mysql error:" << mysql_error(pDB) << std::endl;
			return -1;
		}
		make_query(pDB);
		sql = "INSERT INTO `hello` (`编号`,`age`) VALUES (\"9526\",35);";
		ret = mysql_real_query(pDB, sql.c_str(), (unsigned long)sql.size());
		if (ret != 0) {
			std::cout << "mysql error:" << mysql_error(pDB) << std::endl;
			return -1;
		}
		make_query(pDB);
		sql = "INSERT INTO `teacher` (`编号`,`age`) VALUES (\"9528\",99);";
		ret = mysql_real_query(pDB, sql.c_str(), (unsigned long)sql.size());
		if (ret != 0) {
			std::cout << "mysql error:" << mysql_error(pDB) << std::endl;
			return -1;
		}
		make_query(pDB);

		sql = "SELECT age FROM `hello` UNION ALL SELECT age FROM `teacher`;";
		ret = mysql_real_query(pDB, sql.c_str(), (unsigned long)sql.size());
		if (ret != 0) {
			std::cout << "mysql error:" << mysql_error(pDB) << std::endl;
			return -1;
		}
		result = mysql_store_result(mysql);
		if (result != NULL) {
			show_result(result);
			std::cout << "===================================================" << std::endl;
			mysql_free_result(result);
		}
		sql = "DROP TABLE `hello`;";
		ret = mysql_real_query(pDB, sql.c_str(), (unsigned long)sql.size());
		if (ret != 0) {
			std::cout << "mysql error:" << mysql_error(pDB) << std::endl;
			return -1;
		}
		sql = "DROP DATABASE hello;";
		ret = mysql_real_query(pDB, sql.c_str(), (unsigned long)sql.size());
		if (ret != 0) {
			std::cout << "mysql error:" << mysql_error(pDB) << std::endl;
			return -1;
		}
		mysql_close(pDB);
	}

	delete mysql;
	return 0;
}

int lession16()
{
	MYSQL* mysql = new MYSQL();
	//MYSQL mysql;//占用的是栈上的内存
	MYSQL* pDB = mysql_init(mysql);
	if (pDB == NULL) {
		std::cout << "mysql_init failed!" << std::endl;
		return -1;
	}
	pDB = mysql_real_connect(pDB, "localhost", "root", "FengPan12#$56", "mysql", 3306, NULL, 0);
	std::cout << pDB << std::endl;
	if (pDB) {
		std::string sql = "CREATE DATABASE hello";
		int ret = mysql_real_query(pDB, sql.c_str(), (unsigned long)sql.size());
		if (ret != 0) {
			std::cout << "mysql error:" << mysql_error(pDB) << std::endl;
		}
		MYSQL_RES* result = mysql_use_result(mysql);
		if (result != NULL) {
			show_result(result);
			std::cout << "===================================================" << std::endl;
			mysql_free_result(result);
		}
		//授予权限
		sql = "GRANT ALL ON hello.* TO 'hello'@'localhost';";
		ret = mysql_real_query(pDB, sql.c_str(), (unsigned long)sql.size());
		if (ret != 0) {
			std::cout << "mysql error:" << mysql_error(pDB) << std::endl;
			return -1;
		}
		result = mysql_use_result(mysql);
		if (result != NULL) {
			show_result(result);
			std::cout << "===================================================" << std::endl;
			mysql_free_result(result);
		}


		sql = "USE hello;";
		ret = mysql_real_query(pDB, sql.c_str(), (unsigned long)sql.size());
		if (ret != 0) {
			std::cout << "mysql error:" << mysql_error(pDB) << std::endl;
			return -1;
		}

		sql = "CREATE TABLE IF NOT EXISTS `hello` (`编号` NVARCHAR(16) PRIMARY KEY,";
		sql += "`age` INT NOT NULL DEFAULT 18";
		sql += ")ENGINE=InnoDB DEFAULT CHARSET=utf8;";
		ret = mysql_real_query(pDB, sql.c_str(), (unsigned long)sql.size());
		if (ret != 0) {
			std::cout << "mysql error:" << mysql_error(pDB) << std::endl;
			return -1;
		}
		sql = "CREATE TABLE IF NOT EXISTS `teacher` (`编号` NVARCHAR(16) PRIMARY KEY,";
		sql += "`age` INT NOT NULL DEFAULT 18";
		sql += ")ENGINE=InnoDB DEFAULT CHARSET=utf8;";
		ret = mysql_real_query(pDB, sql.c_str(), (unsigned long)sql.size());
		if (ret != 0) {
			std::cout << "mysql error:" << mysql_error(pDB) << std::endl;
			return -1;
		}
		sql = "SET NAMES 'utf8';";
		ret = mysql_real_query(pDB, sql.c_str(), (unsigned long)sql.size());
		if (ret != 0) {
			std::cout << "mysql error:" << mysql_error(pDB) << std::endl;
			return -1;
		}
		sql = "SET CHARACTER SET utf8;";
		ret = mysql_real_query(pDB, sql.c_str(), (unsigned long)sql.size());
		if (ret != 0) {
			std::cout << "mysql error:" << mysql_error(pDB) << std::endl;
			return -1;
		}
		/*sql = "SET CHARACTER_SET_RESULT = utf8";
		ret = mysql_real_query(pDB, sql.c_str(), (unsigned long)sql.size());
		if (ret != 0) {
			std::cout << "mysql error:" << mysql_error(pDB) << std::endl;
			return -1;
		}*/
		make_query(pDB);
		sql = "INSERT INTO `hello` (`编号`,`age`) VALUES (\"9527\",35);";
		ret = mysql_real_query(pDB, sql.c_str(), (unsigned long)sql.size());
		if (ret != 0) {
			std::cout << "mysql error:" << mysql_error(pDB) << std::endl;
			return -1;
		}
		make_query(pDB);
		sql = "INSERT INTO `hello` (`编号`,`age`) VALUES (\"9526\",35);";
		ret = mysql_real_query(pDB, sql.c_str(), (unsigned long)sql.size());
		if (ret != 0) {
			std::cout << "mysql error:" << mysql_error(pDB) << std::endl;
			return -1;
		}
		make_query(pDB);
		sql = "INSERT INTO `teacher` (`编号`,`age`) VALUES (\"9528\",99);";
		ret = mysql_real_query(pDB, sql.c_str(), (unsigned long)sql.size());
		if (ret != 0) {
			std::cout << "mysql error:" << mysql_error(pDB) << std::endl;
			return -1;
		}
		make_query(pDB);

		sql = "SELECT age FROM `hello` UNION ALL SELECT age FROM `teacher`;";
		ret = mysql_real_query(pDB, sql.c_str(), (unsigned long)sql.size());
		if (ret != 0) {
			std::cout << "mysql error:" << mysql_error(pDB) << std::endl;
			return -1;
		}
		result = mysql_store_result(mysql);
		if (result != NULL) {
			show_result(result);
			std::cout << "===================================================" << std::endl;
			mysql_free_result(result);
		}
		sql = "CREATE INDEX myindex ON `hello`(age); ";
		ret = mysql_real_query(pDB, sql.c_str(), (unsigned long)sql.size());
		if (ret != 0) {
			std::cout << "mysql error:" << mysql_error(pDB) << std::endl;
			return -1;
		}
		sql = "DROP DATABASE hello;";
		ret = mysql_real_query(pDB, sql.c_str(), (unsigned long)sql.size());
		if (ret != 0) {
			std::cout << "mysql error:" << mysql_error(pDB) << std::endl;
			return -1;
		}
		mysql_close(pDB);
	}

	delete mysql;
	return 0;
}

int lession17()
{
	MYSQL* mysql = new MYSQL();
	//MYSQL mysql;//占用的是栈上的内存
	MYSQL* pDB = mysql_init(mysql);
	if (pDB == NULL) {
		std::cout << "mysql_init failed!" << std::endl;
		return -1;
	}
	pDB = mysql_real_connect(pDB, "localhost", "root", "FengPan12#$56", "mysql", 3306, NULL, CLIENT_LOCAL_FILES);
	std::cout << pDB << std::endl;
	std::string sql;
	int ret = 0;
	if (pDB) {
		sql = "DROP DATABASE IF EXISTS hello;";
		ret = mysql_real_query(pDB, sql.c_str(), (unsigned long)sql.size());
		if (ret != 0) {
			std::cout << "mysql error:" << mysql_error(pDB) << std::endl;
		}
		sql = "CREATE DATABASE hello";
		ret = mysql_real_query(pDB, sql.c_str(), (unsigned long)sql.size());
		if (ret != 0) {
			std::cout << "mysql error:" << mysql_error(pDB) << std::endl;
		}
		MYSQL_RES* result = mysql_use_result(mysql);
		if (result != NULL) {
			show_result(result);
			std::cout << "===================================================" << std::endl;
			mysql_free_result(result);
		}
		//授予权限
		sql = "GRANT ALL ON hello.* TO 'hello'@'localhost';";
		ret = mysql_real_query(pDB, sql.c_str(), (unsigned long)sql.size());
		if (ret != 0) {
			std::cout << "mysql error:" << mysql_error(pDB) << std::endl;
			return -1;
		}
		result = mysql_use_result(mysql);
		if (result != NULL) {
			show_result(result);
			std::cout << "===================================================" << std::endl;
			mysql_free_result(result);
		}


		sql = "USE hello;";
		ret = mysql_real_query(pDB, sql.c_str(), (unsigned long)sql.size());
		if (ret != 0) {
			std::cout << "mysql error:" << mysql_error(pDB) << std::endl;
			return -1;
		}

		sql = "CREATE TABLE IF NOT EXISTS `hello` (`编号` NVARCHAR(16) PRIMARY KEY,";
		sql += "`age` INT NOT NULL DEFAULT 18";
		sql += ")ENGINE=InnoDB DEFAULT CHARSET=utf8;";
		ret = mysql_real_query(pDB, sql.c_str(), (unsigned long)sql.size());
		if (ret != 0) {
			std::cout << "mysql error:" << mysql_error(pDB) << std::endl;
			return -1;
		}
		sql = "CREATE TABLE IF NOT EXISTS `teacher` (`编号` NVARCHAR(16) PRIMARY KEY,";
		sql += "`age` INT NOT NULL DEFAULT 18";
		sql += ")ENGINE=InnoDB DEFAULT CHARSET=utf8;";
		ret = mysql_real_query(pDB, sql.c_str(), (unsigned long)sql.size());
		if (ret != 0) {
			std::cout << "mysql error:" << mysql_error(pDB) << std::endl;
			return -1;
		}
		sql = "CREATE TABLE `logs` ( `Id` int(11) NOT NULL AUTO_INCREMENT, `log` varchar(255) DEFAULT NULL COMMENT \"日志说明\",  PRIMARY KEY(`Id`) ) ENGINE = InnoDB DEFAULT CHARSET = utf8mb4 COMMENT = \"日志\";";
		ret = mysql_real_query(pDB, sql.c_str(), (unsigned long)sql.size());
		if (ret != 0) {
			std::cout << "mysql error:" << mysql_error(pDB) << std::endl;
			return -1;
		}
		sql = "CREATE TRIGGER hello_log AFTER INSERT ON `hello` FOR EACH ROW \n \
		 BEGIN\n \
		 DECLARE s1 VARCHAR(40)character set utf8;\n \
		 DECLARE s2 VARCHAR(20) character set utf8;\n \
		 SET s2 = \" is created\";\n \
		 SET s1 = CONCAT(NEW.`编号`, s2);\n \
		 INSERT INTO logs(log) values(s1);\n \
		 END;";///
		ret = mysql_real_query(pDB, sql.c_str(), (unsigned long)sql.size());
		if (ret != 0) {
			std::cout << "mysql error:" << mysql_error(pDB) << std::endl;
			return -1;
		}
		sql = "SET NAMES 'utf8';";
		ret = mysql_real_query(pDB, sql.c_str(), (unsigned long)sql.size());
		if (ret != 0) {
			std::cout << "mysql error:" << mysql_error(pDB) << std::endl;
			return -1;
		}
		sql = "SET CHARACTER SET utf8;";
		ret = mysql_real_query(pDB, sql.c_str(), (unsigned long)sql.size());
		if (ret != 0) {
			std::cout << "mysql error:" << mysql_error(pDB) << std::endl;
			return -1;
		}
		make_query(pDB);

		ret = mysql_autocommit(mysql, false);
		sql = "INSERT INTO `hello` (`编号`,`age`) VALUES (\"9527\",35);";
		ret = mysql_real_query(pDB, sql.c_str(), (unsigned long)sql.size());
		if (ret != 0) {
			std::cout << "mysql error:" << mysql_error(pDB) << std::endl;
			return -1;
		}
		ret = mysql_rollback(mysql);
		make_query(pDB);
		sql = "INSERT INTO `hello` (`编号`,`age`) VALUES (\"9526\",35);";
		ret = mysql_real_query(pDB, sql.c_str(), (unsigned long)sql.size());
		if (ret != 0) {
			std::cout << "mysql error:" << mysql_error(pDB) << std::endl;
			return -1;
		}
		make_query(pDB);
		sql = "INSERT INTO `teacher` (`编号`,`age`) VALUES (\"9528\",99);";
		ret = mysql_real_query(pDB, sql.c_str(), (unsigned long)sql.size());
		if (ret != 0) {
			std::cout << "mysql error:" << mysql_error(pDB) << std::endl;
			return -1;
		}
		ret = mysql_commit(mysql);
		ret = mysql_autocommit(mysql, true);

		sql = "SELECT age FROM `hello` UNION ALL SELECT age FROM `teacher`;";
		ret = mysql_real_query(pDB, sql.c_str(), (unsigned long)sql.size());
		if (ret != 0) {
			std::cout << "mysql error:" << mysql_error(pDB) << std::endl;
			return -1;
		}
		result = mysql_store_result(mysql);
		if (result != NULL) {
			show_result(result);
			std::cout << "===================================================" << std::endl;
			mysql_free_result(result);
		}
		sql = "CREATE INDEX myindex ON `hello`(age); ";
		ret = mysql_real_query(pDB, sql.c_str(), (unsigned long)sql.size());
		if (ret != 0) {
			std::cout << "mysql error:" << mysql_error(pDB) << std::endl;
			return -1;
		}
		sql = "DROP DATABASE hello;";
		ret = mysql_real_query(pDB, sql.c_str(), (unsigned long)sql.size());
		if (ret != 0) {
			std::cout << "mysql error:" << mysql_error(pDB) << std::endl;
			return -1;
		}
		mysql_close(pDB);
	}

	delete mysql;
	return 0;
}
int lession19()
{
	MYSQL* mysql = new MYSQL();
	//MYSQL mysql;//占用的是栈上的内存
	MYSQL* pDB = mysql_init(mysql);
	if (pDB == NULL) {
		std::cout << "mysql_init failed!" << std::endl;
		return -1;
	}
	pDB = mysql_real_connect(pDB, "localhost", "root", "FengPan12#$56", "mysql", 3306, NULL, CLIENT_LOCAL_FILES);
	std::cout << pDB << std::endl;
	std::string sql;
	int ret = 0;
	if (pDB) {
		sql = "DROP DATABASE IF EXISTS hello;";
		ret = mysql_real_query(pDB, sql.c_str(), (unsigned long)sql.size());
		if (ret != 0) {
			std::cout << "mysql error:" << mysql_error(pDB) << std::endl;
		}
		sql = "CREATE DATABASE hello";
		ret = mysql_real_query(pDB, sql.c_str(), (unsigned long)sql.size());
		if (ret != 0) {
			std::cout << "mysql error:" << mysql_error(pDB) << std::endl;
		}
		MYSQL_RES* result = mysql_use_result(mysql);
		if (result != NULL) {
			show_result(result);
			std::cout << "===================================================" << std::endl;
			mysql_free_result(result);
		}
		//授予权限
		sql = "GRANT ALL ON hello.* TO 'hello'@'localhost';";
		ret = mysql_real_query(pDB, sql.c_str(), (unsigned long)sql.size());
		if (ret != 0) {
			std::cout << "mysql error:" << mysql_error(pDB) << std::endl;
			return -1;
		}
		result = mysql_use_result(mysql);
		if (result != NULL) {
			show_result(result);
			std::cout << "===================================================" << std::endl;
			mysql_free_result(result);
		}


		sql = "USE hello;";
		ret = mysql_real_query(pDB, sql.c_str(), (unsigned long)sql.size());
		if (ret != 0) {
			std::cout << "mysql error:" << mysql_error(pDB) << std::endl;
			return -1;
		}

		sql = "CREATE TABLE IF NOT EXISTS `hello` (`编号` NVARCHAR(16) PRIMARY KEY,";
		sql += "`age` INT NOT NULL DEFAULT 18";
		sql += ")ENGINE=InnoDB DEFAULT CHARSET=utf8;";
		ret = mysql_real_query(pDB, sql.c_str(), (unsigned long)sql.size());
		if (ret != 0) {
			std::cout << "mysql error:" << mysql_error(pDB) << std::endl;
			return -1;
		}
		sql = "CREATE TABLE IF NOT EXISTS `teacher` (`编号` NVARCHAR(16) PRIMARY KEY,";
		sql += "`age` INT NOT NULL DEFAULT 18";
		sql += ")ENGINE=InnoDB DEFAULT CHARSET=utf8;";
		ret = mysql_real_query(pDB, sql.c_str(), (unsigned long)sql.size());
		if (ret != 0) {
			std::cout << "mysql error:" << mysql_error(pDB) << std::endl;
			return -1;
		}
		sql = "CREATE TABLE `logs` ( `Id` int(11) NOT NULL AUTO_INCREMENT, `log` varchar(255) DEFAULT NULL COMMENT \"日志说明\",  PRIMARY KEY(`Id`) ) ENGINE = InnoDB DEFAULT CHARSET = utf8mb4 COMMENT = \"日志\";";
		ret = mysql_real_query(pDB, sql.c_str(), (unsigned long)sql.size());
		if (ret != 0) {
			std::cout << "mysql error:" << mysql_error(pDB) << std::endl;
			return -1;
		}
		sql = "CREATE TRIGGER hello_log AFTER INSERT ON `hello` FOR EACH ROW \n \
		 BEGIN\n \
		 DECLARE s1 VARCHAR(40)character set utf8;\n \
		 DECLARE s2 VARCHAR(20) character set utf8;\n \
		 SET s2 = \" is created\";\n \
		 SET s1 = CONCAT(NEW.`编号`, s2, CURRENT_TIMESTAMP());\n \
		 INSERT INTO logs(log) values(s1);\n \
		 END;";///
		ret = mysql_real_query(pDB, sql.c_str(), (unsigned long)sql.size());
		if (ret != 0) {
			std::cout << "mysql error:" << mysql_error(pDB) << std::endl;
			return -1;
		}
		sql = "SET NAMES 'utf8';";
		ret = mysql_real_query(pDB, sql.c_str(), (unsigned long)sql.size());
		if (ret != 0) {
			std::cout << "mysql error:" << mysql_error(pDB) << std::endl;
			return -1;
		}
		sql = "SET CHARACTER SET utf8;";
		ret = mysql_real_query(pDB, sql.c_str(), (unsigned long)sql.size());
		if (ret != 0) {
			std::cout << "mysql error:" << mysql_error(pDB) << std::endl;
			return -1;
		}
		make_query(pDB);

		ret = mysql_autocommit(mysql, false);
		sql = "INSERT INTO `hello` (`编号`,`age`) VALUES (\"9527\",35);";
		ret = mysql_real_query(pDB, sql.c_str(), (unsigned long)sql.size());
		if (ret != 0) {
			std::cout << "mysql error:" << mysql_error(pDB) << std::endl;
			return -1;
		}
		ret = mysql_rollback(mysql);
		make_query(pDB);
		sql = "INSERT INTO `hello` (`编号`,`age`) VALUES (\"9526\",35);";
		ret = mysql_real_query(pDB, sql.c_str(), (unsigned long)sql.size());
		if (ret != 0) {
			std::cout << "mysql error:" << mysql_error(pDB) << std::endl;
			return -1;
		}
		make_query(pDB);
		sql = "INSERT INTO `teacher` (`编号`,`age`) VALUES (\"9528\",99);";
		ret = mysql_real_query(pDB, sql.c_str(), (unsigned long)sql.size());
		if (ret != 0) {
			std::cout << "mysql error:" << mysql_error(pDB) << std::endl;
			return -1;
		}
		ret = mysql_commit(mysql);
		ret = mysql_autocommit(mysql, true);

		sql = "SELECT age FROM `hello` UNION ALL SELECT age FROM `teacher`;";
		ret = mysql_real_query(pDB, sql.c_str(), (unsigned long)sql.size());
		if (ret != 0) {
			std::cout << "mysql error:" << mysql_error(pDB) << std::endl;
			return -1;
		}
		result = mysql_store_result(mysql);
		if (result != NULL) {
			show_result(result);
			std::cout << "===================================================" << std::endl;
			mysql_free_result(result);
		}
		sql = "CREATE INDEX myindex ON `hello`(age); ";
		ret = mysql_real_query(pDB, sql.c_str(), (unsigned long)sql.size());
		if (ret != 0) {
			std::cout << "mysql error:" << mysql_error(pDB) << std::endl;
			return -1;
		}
		sql = "SELECT * FROM `hello` INTO OUTFILE 'C:/ProgramData/MySQL/MySQL Server 8.0/Uploads/hello.txt'\n \
			FIELDS TERMINATED BY ',' \n \
			LINES TERMINATED BY '\r\n'";
		ret = mysql_real_query(pDB, sql.c_str(), (unsigned long)sql.size());
		if (ret != 0) {
			std::cout << "mysql error:" << mysql_error(pDB) << std::endl;
			return -1;
		}
		sql = "DELETE FROM `hello`;";
		ret = mysql_real_query(pDB, sql.c_str(), (unsigned long)sql.size());
		if (ret != 0) {
			std::cout << "mysql error:" << mysql_error(pDB) << std::endl;
			return -1;
		}

		sql = "LOAD DATA LOCAL INFILE 'C:/ProgramData/MySQL/MySQL Server 8.0/Uploads/hello.txt' INTO TABLE `hello`\n \
			FIELDS TERMINATED BY ',' \n \
			LINES TERMINATED BY '\r\n'";
		ret = mysql_real_query(pDB, sql.c_str(), (unsigned long)sql.size());
		if (ret != 0) {
			std::cout << "mysql error:" << mysql_error(pDB) << std::endl;
			//mysqlimport -u root -pFengPan12#$56 --local hello "C:/ProgramData/MySQL/MySQL Server 8.0/Uploads/hello.txt" --fields-terminated-by=","  --lines-terminated-by="\r\n"
			std::string cmd = "mysqlimport -u root -pFengPan12#$56 --local hello ";
			cmd += "\"C:/ProgramData/MySQL/MySQL Server 8.0/Uploads/hello.txt\" ";
			cmd += "--fields-terminated-by=\",\"  --lines-terminated-by=\"\\r\\n\"";
			system(cmd.c_str());
		}
		mysql_close(mysql);
		mysql_init(mysql);
		pDB = mysql_real_connect(mysql, "localhost", "root", "FengPan12#$56", "hello", 3306, NULL, 0);
		sql = "SELECT COUNT(*) FROM `hello`;";
		ret = mysql_real_query(pDB, sql.c_str(), (unsigned long)sql.size());
		if (ret != 0) {
			std::cout << "mysql error:" << mysql_error(pDB) << std::endl;
			return -1;
		}
		result = mysql_store_result(mysql);
		if (result != NULL) {
			show_result(result);
			std::cout << "===================================================" << std::endl;
			mysql_free_result(result);
		}

		sql = "DROP DATABASE hello;";
		ret = mysql_real_query(pDB, sql.c_str(), (unsigned long)sql.size());
		if (ret != 0) {
			std::cout << "mysql error:" << mysql_error(pDB) << std::endl;
			return -1;
		}
		mysql_close(pDB);
	}

	delete mysql;
	return 0;
}
int main()
{
	//lession04();
	//lession07();
	//lession08();
	//lession09();
	//lession10();
	//lession11();
	//lession12();
	//lession13();
	setlocale(LC_ALL, "en_GB.UTF-8");//设置控制台编码
	//lession14();
	//lession16();
	//lession17();
	lession19();
	return 0;
}

